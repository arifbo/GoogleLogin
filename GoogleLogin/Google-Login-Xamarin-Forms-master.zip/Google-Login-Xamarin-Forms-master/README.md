# Google-Login-Xamarin-Forms
Provides source code for Login with Google API in Xamarin Forms apps.

Watch this video for more details:
<a href="https://youtu.be/AgFIsVr26zg">https://youtu.be/AgFIsVr26zg</a>

<a href="https://youtu.be/AgFIsVr26zg">
<img src="https://github.com/HoussemDellai/Google-Login-Xamarin-Forms/blob/master/items/google%20login1.png?raw=true" width="60%"/>
</a>

